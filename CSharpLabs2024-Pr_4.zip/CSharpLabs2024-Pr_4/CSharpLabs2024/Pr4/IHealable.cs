namespace Pr4;

public interface IHealable
{
    void TakeHealing(int healing);
}