namespace Pr4;

public interface IDamageable
{
    
    void TakeDamage(int damage);
}