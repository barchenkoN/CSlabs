﻿namespace Pr4;

class Program
{
    static void Main(string[] args)
    {
        GameLogic game = new GameLogic();
        
        // game.OnGameStart += OnGameStarted;
        // game.OnGameEnd += OnGameEnd;
        
        game.StartPvPGame();



        // Player testPlayer1 = new Mage("Alexander", "Efimov", 100,MagicType.Fire,spellsByMagic[MagicType.Fire], 10 );
        // Player testPlayer2 = new Mage("Vitalii", "Kasianenko", 100,MagicType.Water,spellsByMagic[MagicType.Water], 10);


        // magicList.PrintMagicInfo();
        //
        // ((Mage)testPlayer1).PrintSpellsList();
        //
        // testPlayer1.CastSpell(0,testPlayer2);
        // testPlayer2.CastSpell(1,testPlayer2);

    }

    public static void OnGameStarted()
    {
        Console.WriteLine("Game has started, Get Ready!");
    }
    
    public static void OnGameEnd()
    {
        Console.WriteLine("Game Over, GG!");
    }
}