namespace Pr4;

public enum MagicType
{
    Fire,
    Water,
    DevPower
}